#!/usr/bin/env python3
"""
Script to restructure liturgical JSON files to match the new Morning class structure.

Transforms:
- celebrationTitle, celebrationSubtitle, etc. -> celebration{title, subtitle, ...}
- invitatoryAntiphon, invitatoryPsalms -> invitatory{antiphon, psalms}
- evangelicAntiphon, evangelicAntiphonA/B/C -> evangelicAntiphon{common, yearA/B/C}
- intercessionDescription, intercession -> intercession{description, content}
- readingRef, reading (in morning class) -> reading{biblicalReference, content}
- oration, oration2 -> oration (as list)
- Orders keys according to DayOffices class structure
"""

import json
import os
import sys
from pathlib import Path
from typing import Dict, Any, List, Optional
from collections import OrderedDict


# Define the logical order of keys
ROOT_KEY_ORDER = [
    'celebration',
    'firstVespers',
    'invitatory',
    'morning',
    'readings',
    'middleOfDay',
    'vespers',
    # Legacy fields
    'sundayEvangelicAntiphonA',
    'sundayEvangelicAntiphonB',
    'sundayEvangelicAntiphonC',
    'evangelicAntiphon',
    'oration',
]

OFFICE_KEY_ORDER = [
    'hymn',
    'psalmody',
    'reading',
    'biblicalReading',
    'biblicalReading2',
    'patristicReading',
    'patristicReading2',
    'patristicReading3',
    'verse',
    'responsory',
    'evangelicAntiphon',
    'intercession',
    'intercession2',
    'oration',
]


def ordered_dict_from_keys(data: Dict[str, Any], key_order: List[str]) -> OrderedDict:
    """
    Create an OrderedDict with keys in the specified order.
    Keys not in key_order are appended at the end in their original order.
    """
    result = OrderedDict()
    
    # First add keys in the specified order
    for key in key_order:
        if key in data:
            result[key] = data[key]
    
    # Then add any remaining keys not in the order list
    for key in data:
        if key not in result:
            result[key] = data[key]
    
    return result


def restructure_celebration(data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Extract and restructure celebration-related fields.
    
    Returns None if no celebration fields are present.
    """
    celebration_fields = {
        'celebrationTitle': 'title',
        'celebrationSubtitle': 'subtitle',
        'celebrationDescription': 'description',
        'commons': 'commons',
        'liturgicalGrade': 'grade',
        'celebration Grade': 'grade',  # Handle typo in example
        'liturgicalColor': 'color',
    }
    
    celebration = {}
    for old_key, new_key in celebration_fields.items():
        if old_key in data:
            celebration[new_key] = data[old_key]
    
    return celebration if celebration else None


def restructure_invitatory(data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Extract and restructure invitatory-related fields from root level.
    
    Returns None if no invitatory fields are present.
    """
    invitatory = {}
    
    if 'invitatoryAntiphon' in data:
        invitatory['antiphon'] = data['invitatoryAntiphon']
    
    if 'invitatoryPsalms' in data:
        invitatory['psalms'] = data['invitatoryPsalms']
    
    return invitatory if invitatory else None


def restructure_reading(office_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Extract and restructure reading fields from an office structure.
    
    Transforms readingRef -> biblicalReference, reading -> content
    Returns None if no reading fields are present.
    """
    reading = {}
    
    # Handle old structure (ref/content)
    if 'reading' in office_data:
        old_reading = office_data['reading']
        if isinstance(old_reading, dict):
            if 'ref' in old_reading:
                reading['biblicalReference'] = old_reading['ref']
            if 'content' in old_reading:
                reading['content'] = old_reading['content']
        elif isinstance(old_reading, str):
            # If reading is just a string, assume it's content
            reading['content'] = old_reading
    
    # Handle separate readingRef field at office level
    if 'readingRef' in office_data:
        reading['biblicalReference'] = office_data['readingRef']
    
    return reading if reading else None


def restructure_evangelic_antiphon(office_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Extract and restructure evangelic antiphon fields from an office structure.
    
    Returns None if no evangelic antiphon fields are present.
    """
    evangelic = {}
    
    if 'evangelicAntiphon' in office_data:
        evangelic['common'] = office_data['evangelicAntiphon']
    
    if 'evangelicAntiphonA' in office_data:
        evangelic['yearA'] = office_data['evangelicAntiphonA']
    
    if 'evangelicAntiphonB' in office_data:
        evangelic['yearB'] = office_data['evangelicAntiphonB']
    
    if 'evangelicAntiphonC' in office_data:
        evangelic['yearC'] = office_data['evangelicAntiphonC']
    
    return evangelic if evangelic else None


def restructure_intercession(office_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Extract and restructure intercession fields from an office structure.
    
    Returns None if no intercession fields are present.
    """
    intercession = {}
    
    if 'intercessionDescription' in office_data:
        intercession['description'] = office_data['intercessionDescription']
    
    if 'intercession' in office_data:
        intercession['content'] = office_data['intercession']
    
    return intercession if intercession else None


def restructure_oration(office_data: Dict[str, Any]) -> Optional[List[str]]:
    """
    Extract and restructure oration field(s) into a list.
    
    Returns None if no oration fields are present.
    """
    orations = []
    
    # Handle case where oration is already a list
    if 'oration' in office_data:
        if isinstance(office_data['oration'], list):
            orations.extend(office_data['oration'])
        else:
            orations.append(office_data['oration'])
    
    if 'oration2' in office_data:
        orations.append(office_data['oration2'])
    
    return orations if orations else None


def restructure_office(office_data: Dict[str, Any], office_type: str) -> Dict[str, Any]:
    """
    Restructure an office section (morning, vespers, readings, etc.).
    
    Args:
        office_data: The office data dictionary
        office_type: Type of office ('morning', 'vespers', 'readings', etc.)
    
    Returns:
        Restructured office data with proper key ordering
    """
    restructured = {}
    
    # Fields that should be kept as-is
    keep_fields = ['hymn', 'psalmody', 'responsory', 'verse']
    for field in keep_fields:
        if field in office_data:
            restructured[field] = office_data[field]
    
    # Handle biblicalReading and patristicReading for readings office
    if office_type == 'readings':
        for reading_field in ['biblicalReading', 'biblicalReading2', 
                              'patristicReading', 'patristicReading2', 'patristicReading3']:
            if reading_field in office_data:
                restructured[reading_field] = office_data[reading_field]
    
    # Restructure reading
    reading = restructure_reading(office_data)
    if reading:
        restructured['reading'] = reading
    
    # Restructure evangelic antiphon
    evangelic = restructure_evangelic_antiphon(office_data)
    if evangelic:
        restructured['evangelicAntiphon'] = evangelic
    
    # Restructure intercession
    intercession = restructure_intercession(office_data)
    if intercession:
        restructured['intercession'] = intercession
    
    # Handle intercession2 separately if present (morning office)
    if 'intercession2' in office_data:
        restructured['intercession2'] = office_data['intercession2']
    
    # Restructure oration
    oration = restructure_oration(office_data)
    if oration:
        restructured['oration'] = oration
    
    # Order keys according to OFFICE_KEY_ORDER
    return dict(ordered_dict_from_keys(restructured, OFFICE_KEY_ORDER))


def restructure_middle_of_day(middle_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Restructure middle of day office, handling tierce/sexte/none.
    """
    restructured = {}
    
    # Keep psalmody as-is
    if 'psalmody' in middle_data:
        restructured['psalmody'] = middle_data['psalmody']
    
    # Keep legacy psalm fields
    for psalm_field in ['psalm1', 'psalm2', 'psalm3']:
        if psalm_field in middle_data:
            restructured[psalm_field] = middle_data[psalm_field]
    
    # Handle tierce, sexte, none - restructure their reading fields
    for hour in ['tierce', 'sexte', 'none']:
        if hour in middle_data and isinstance(middle_data[hour], dict):
            hour_data = middle_data[hour].copy()
            
            # Restructure reading in hour
            if 'reading' in hour_data:
                reading = restructure_reading({'reading': hour_data['reading']})
                if reading:
                    hour_data['reading'] = reading
            
            restructured[hour] = hour_data
    
    # Restructure oration
    oration = restructure_oration(middle_data)
    if oration:
        restructured['oration'] = oration
    
    return restructured


def restructure_json_file(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Restructure an entire JSON file according to the new schema.
    
    Args:
        data: The original JSON data
    
    Returns:
        Restructured JSON data with proper key ordering
    """
    restructured = {}
    
    # 1. Restructure celebration (from root level)
    celebration = restructure_celebration(data)
    if celebration:
        restructured['celebration'] = celebration
    
    # 2. Restructure invitatory (from root level)
    invitatory_root = restructure_invitatory(data)
    if invitatory_root:
        restructured['invitatory'] = invitatory_root
    
    # Handle invitatory office if present (different from root invitatory fields)
    if 'invitatory' in data and isinstance(data['invitatory'], dict):
        if 'antiphon' in data['invitatory'] or 'psalm' in data['invitatory']:
            restructured['invitatory'] = data['invitatory']
    
    # 3. Restructure each office type
    office_types = ['morning', 'vespers', 'firstVespers', 'readings']
    for office_type in office_types:
        if office_type in data and isinstance(data[office_type], dict):
            restructured[office_type] = restructure_office(
                data[office_type], 
                office_type
            )
    
    # 4. Handle middle of day office specially
    if 'middleOfDay' in data and isinstance(data['middleOfDay'], dict):
        restructured['middleOfDay'] = restructure_middle_of_day(data['middleOfDay'])
    
    # 5. Handle root-level legacy fields that might still be needed
    legacy_root_fields = [
        'sundayEvangelicAntiphonA',
        'sundayEvangelicAntiphonB', 
        'sundayEvangelicAntiphonC',
    ]
    for field in legacy_root_fields:
        if field in data:
            restructured[field] = data[field]
    
    # Handle root-level evangelicAntiphon (legacy)
    if 'evangelicAntiphon' in data and not isinstance(data.get('morning'), dict):
        restructured['evangelicAntiphon'] = data['evangelicAntiphon']
    
    # Handle root-level oration
    root_oration = restructure_oration(data)
    if root_oration:
        restructured['oration'] = root_oration
    
    # Order keys according to ROOT_KEY_ORDER
    return dict(ordered_dict_from_keys(restructured, ROOT_KEY_ORDER))


def process_file(input_path: Path, output_path: Path, dry_run: bool = False) -> bool:
    """
    Process a single JSON file.
    
    Args:
        input_path: Path to input JSON file
        output_path: Path to output JSON file
        dry_run: If True, don't write the file, just check
    
    Returns:
        True if successful, False otherwise
    """
    try:
        # Read input file
        with open(input_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # Restructure the data
        restructured = restructure_json_file(data)
        
        # Write output file (unless dry run)
        if not dry_run:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(restructured, f, ensure_ascii=False, indent=2)
        
        print(f"✓ Processed: {input_path.relative_to(input_path.parent.parent)}")
        return True
        
    except json.JSONDecodeError as e:
        print(f"✗ JSON error in {input_path}: {e}", file=sys.stderr)
        return False
    except Exception as e:
        print(f"✗ Error processing {input_path}: {e}", file=sys.stderr)
        return False


def process_directory(input_dir: Path, output_dir: Path, dry_run: bool = False) -> tuple:
    """
    Process all JSON files in a directory and its subdirectories.
    
    Args:
        input_dir: Input directory path
        output_dir: Output directory path
        dry_run: If True, don't write files
    
    Returns:
        Tuple of (success_count, error_count)
    """
    success_count = 0
    error_count = 0
    
    # Find all JSON files
    json_files = list(input_dir.rglob('*.json'))
    
    if not json_files:
        print(f"No JSON files found in {input_dir}")
        return (0, 0)
    
    print(f"Found {len(json_files)} JSON files to process")
    if dry_run:
        print("DRY RUN - No files will be modified")
    print()
    
    for json_file in json_files:
        # Calculate relative path to preserve directory structure
        relative_path = json_file.relative_to(input_dir)
        output_file = output_dir / relative_path
        
        if process_file(json_file, output_file, dry_run):
            success_count += 1
        else:
            error_count += 1
    
    return (success_count, error_count)


def main():
    """Main function to handle command-line interface."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Restructure liturgical JSON files to new schema',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Process files in-place (overwrites originals!)
  python restructure_json.py assets/calendar_data
  
  # Process to a different output directory
  python restructure_json.py assets/calendar_data assets/calendar_data_new
  
  # Dry run to check what would be changed
  python restructure_json.py assets/calendar_data --dry-run
  
  # Process single file
  python restructure_json.py assets/calendar_data/special_days/immaculate_conception.json
        """
    )
    
    parser.add_argument(
        'input_path',
        help='Input directory or file path'
    )
    parser.add_argument(
        'output_path',
        nargs='?',
        help='Output directory or file path (defaults to input_path for in-place editing)'
    )
    parser.add_argument(
        '--dry-run',
        action='store_true',
        help='Check files without writing changes'
    )
    parser.add_argument(
        '--backup',
        action='store_true',
        help='Create .bak backup files before overwriting'
    )
    
    args = parser.parse_args()
    
    input_path = Path(args.input_path)
    output_path = Path(args.output_path) if args.output_path else input_path
    
    # Check if input exists
    if not input_path.exists():
        print(f"Error: Input path does not exist: {input_path}", file=sys.stderr)
        sys.exit(1)
    
    # Create backup if requested and doing in-place edit
    if args.backup and input_path == output_path and not args.dry_run:
        import shutil
        backup_path = Path(str(input_path) + '.bak')
        if input_path.is_file():
            shutil.copy2(input_path, backup_path)
            print(f"Created backup: {backup_path}")
        else:
            shutil.copytree(input_path, backup_path, dirs_exist_ok=True)
            print(f"Created backup directory: {backup_path}")
        print()
    
    # Process file or directory
    if input_path.is_file():
        # Single file
        if output_path.is_dir():
            output_file = output_path / input_path.name
        else:
            output_file = output_path
        
        success = process_file(input_path, output_file, args.dry_run)
        sys.exit(0 if success else 1)
    else:
        # Directory
        success_count, error_count = process_directory(
            input_path, 
            output_path, 
            args.dry_run
        )
        
        print()
        print(f"Summary:")
        print(f"  Success: {success_count}")
        print(f"  Errors:  {error_count}")
        
        sys.exit(0 if error_count == 0 else 1)


if __name__ == '__main__':
    main()